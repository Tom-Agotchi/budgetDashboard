'use strict'
module.exports = require(__dirname + '/../test-helper')
